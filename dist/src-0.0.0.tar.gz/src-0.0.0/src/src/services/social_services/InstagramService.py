#TODO : Instagram on hold for the time being, because of API limitations
class InstagramService:
    pass