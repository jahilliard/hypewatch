from src.src.models.Instagram.InstagramProfile import InstagramProfile

#TODO : Instagram on hold for the time being, because of API limitations
class InstagramController:
    pass

