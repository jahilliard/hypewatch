from src.src import BaseModel


class InstagramProfile(BaseModel):
    pass