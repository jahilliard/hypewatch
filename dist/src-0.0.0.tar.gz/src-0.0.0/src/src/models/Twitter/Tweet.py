from src.src import BaseModel


class Tweet(BaseModel):
    pass