import setuptools
setuptools.setup(name="src", packages=setuptools.find_packages())